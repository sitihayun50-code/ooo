// EDIT LINK DI BAWAH INI DENGAN LINK AKUN RESMI LOLON JUJU
const LINKS = {
  discord: "https://discord.gg/GANTI-LINK-DISCORD",
  saweria: "https://saweria.co/banglolon18",
  youtube: "https://www.youtube.com/@LolonJuju",
  tiktok: "https://www.tiktok.com/@banglolon18",
  instagram: "https://instagram.com/GANTI-USERNAME"
};

document.querySelectorAll("[data-link]").forEach(el => {
  const key = el.dataset.link;
  if (LINKS[key]) el.href = LINKS[key];
  el.target = "_blank";
  el.rel = "noopener noreferrer";
});

const toggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");
toggle.addEventListener("click", () => nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => nav.classList.remove("open")));
document.getElementById("year").textContent = new Date().getFullYear();

(() => {const l=document.getElementById("siteLoader"),b=document.getElementById("loaderBar"),t=document.getElementById("loaderText");if(!l||!b||!t)return;let n=5;const timer=setInterval(()=>{n=Math.min(n+Math.ceil(Math.random()*13),92);b.style.width=n+"%"},140);const done=()=>{clearInterval(timer);b.style.width="100%";t.textContent="WEBSITE SIAP!";setTimeout(()=>l.classList.add("done"),350)};if(document.readyState==="complete")done();else window.addEventListener("load",done,{once:true});setTimeout(done,4500)})();
